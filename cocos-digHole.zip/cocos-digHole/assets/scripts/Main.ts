import { _decorator, Component } from "cc";
import { Touch, TouchParam } from "./touch/Touch";
import { SubHole } from "./subHole/SubHole";
import { SubHoleStyle } from "./subHole/SubHoleStyle";
import { TargetWall } from "./targetWall/TargetWall";
import { UITransform } from "cc";
import { Rect } from "cc";
import PolygonVisionUtility from "./PolygonVisionUtility";
import { Node } from "cc";
import { Vec2 } from "cc";
import { PolygonUtility } from "./PolygonUtility";
import * as Flatten from "@flatten-js/core";
import { Sprite } from "cc";
const { ccclass, property } = _decorator;

export interface IMain {
    tryDig(touchParam: TouchParam): void;
    convertTouchPoint(touchPoint: Vec2): PolygonUtility.Point;
}

@ccclass
export default class Main extends Component implements IMain {

    convertTouchPoint(touchPoint: Vec2): PolygonUtility.Point {
        return [touchPoint.x - this.uiTransform.width / 2, touchPoint.y - this.uiTransform.height / 2];
    }

    tryDig(touchParam: TouchParam) {
        let polygon = SubHole.Get(SubHoleStyle.Circle).createHoleVertices(
            touchParam.point,
            touchParam.connectHole,
            touchParam.delta);
        this.targetWall.dig(new Flatten.Polygon(polygon));
        this.polygonVisionUtility.draw(this.targetWall.getPolygons());
    }

    private sprite: Node;
    private touch: Touch;
    private targetWall: TargetWall;
    private polygonVisionUtility: PolygonVisionUtility;

    private uiTransform: UITransform;

    protected start() {
        this.sprite = this.node.getChildByName("Sprite");
        this.uiTransform = this.getComponent(UITransform);

        this.touch = this.getComponentInChildren(Touch);
        this.touch.initialize(this);

        this.targetWall = new TargetWall();
        let wallTransform = this.sprite.getComponent(UITransform);
        this.targetWall.initialize(new Rect(
            -wallTransform.width / 2,
            -wallTransform.height / 2,
            wallTransform.width,
            wallTransform.height
        ));

        this.polygonVisionUtility = this.getComponentInChildren(PolygonVisionUtility);
        this.polygonVisionUtility.draw(this.targetWall.getPolygons());
    }
}