import { Vec2 } from "cc";
import * as Flatten from "@flatten-js/core";
import earcut from "earcut";

export namespace PolygonUtility {

    export type Point = [number, number];
    export type Polygon = Array<Point>;

    export function dot(vec1: Point, vec2: Point): number {
        return vec1[0] * vec2[0] + vec1[1] * vec2[1];
    }

    export function angleToRadian(angle: number): number {
        return angle * Math.PI / 180;
    }

    export function radianToAngle(radian: number): number {
        return radian * 180 / Math.PI;
    }

    export function diff(source: Array<Flatten.Polygon>, target: Flatten.Polygon): Array<Flatten.Polygon> {
        let result = new Array<Flatten.Polygon>();
        for (let i = 0; i < source.length; i++) {
            let polygon = source[i];
            let diffResult = Flatten.BooleanOperations.subtract(polygon, target);
            result.push(diffResult);
        }
        return result;
    }

    export function vec2ToPoint(vec2: Vec2): Point {
        if (vec2 == null) {
            return null;
        }
        return [vec2.x, vec2.y];
    }
}