import { Graphics } from "cc";
import { _decorator, Component } from "cc";
import * as Flatten from "@flatten-js/core";
const { ccclass, property } = _decorator;

@ccclass
export default class PolygonVisionUtility extends Component {
    private graphics: Graphics;

    protected onLoad(): void {
        this.graphics = this.getComponent(Graphics);
    }

    draw(polygons: Array<Flatten.Polygon>) {
        this.graphics.clear();
        for (let i = 0; i < polygons.length; i++) {
            let polygon = polygons[i];
            polygon.faces.forEach(face => {
                this.drawByFace(face);
            });
        }
        this.graphics.stroke();
    }

    private drawByFace(face: Flatten.Face) {
        let first = face.first;
        let next = first;
        let isStartPoint = true;
        do {
            let point = next.start;
            if (isStartPoint) {
                this.graphics.moveTo(point.x, point.y);
            } else {
                this.graphics.lineTo(point.x, point.y);
            }
            next = next.next;
            isStartPoint = false;
        } while (first != next);
        this.graphics.close();
    }
}