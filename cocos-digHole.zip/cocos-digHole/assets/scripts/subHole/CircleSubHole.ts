import { SubHole, registerSubHole } from "./SubHole";
import { SubHoleStyle } from "./SubHoleStyle";
import { PolygonUtility } from "../PolygonUtility";

@registerSubHole(SubHoleStyle.Circle)
export class CircleSubHole extends SubHole {

    radius: number = 20;
    vertexCount: number = 20;

    createHoleVertices(centerPoint: PolygonUtility.Point, connectHole: boolean, delta: PolygonUtility.Point): PolygonUtility.Polygon {
        let polygon: PolygonUtility.Polygon = [];
        let radian = PolygonUtility.angleToRadian(360 / this.vertexCount);
        if (!connectHole) {
            for (let i = 0; i < this.vertexCount; i++) {
                let x = centerPoint[0] + this.radius * Math.cos(radian * i);
                let y = centerPoint[1] + this.radius * Math.sin(radian * i);
                polygon.push([x, y]);
            }
        } else {
            let prePoint = [centerPoint[0] - delta[0], centerPoint[1] - delta[1]];
            for (let i = 0; i < this.vertexCount; i++) {
                let tempX = this.radius * Math.cos(radian * i);
                let tempY = this.radius * Math.sin(radian * i);
                let dotValue = PolygonUtility.dot(delta, [tempX, tempY]);
                if (dotValue > 0) {
                    polygon.push([centerPoint[0] + tempX, centerPoint[1] + tempY]);
                } else {
                    polygon.push([prePoint[0] + tempX, prePoint[1] + tempY]);
                }
            }
        }
        return polygon;
    }
}