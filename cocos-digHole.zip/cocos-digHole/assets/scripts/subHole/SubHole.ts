import { SubHoleStyle } from "./SubHoleStyle";
import { PolygonUtility } from "../PolygonUtility";

export interface ISubHole {
    createHoleVertices(centerPoint: PolygonUtility.Point, connectHole: boolean, delta: PolygonUtility.Point): PolygonUtility.Polygon;
}

export function registerSubHole(style: SubHoleStyle) {
    return function (target: new () => ISubHole) {
        SubHole.addHoleClass(style, new target());
    }
}

export abstract class SubHole implements ISubHole {

    private static holeClass = new Map<SubHoleStyle, ISubHole>();
    static addHoleClass(style: SubHoleStyle, cls: ISubHole) {
        if (!this.holeClass.has(style)) {
            this.holeClass.set(style, cls);
        }
    }

    static Get(style: SubHoleStyle): ISubHole {
        let subHole = this.holeClass.get(style);
        if (subHole == null) {
            throw new Error("SubHole not found");
        }
        return subHole;
    }

    abstract createHoleVertices(centerPoint: PolygonUtility.Point, connectHole: boolean, delta: PolygonUtility.Point): PolygonUtility.Polygon;
}