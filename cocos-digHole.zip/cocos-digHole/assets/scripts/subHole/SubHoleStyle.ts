export enum SubHoleStyle {
    Circle,
    Square
}