import { Rect } from "cc";
import { PolygonUtility } from "../PolygonUtility";
import * as Flatten from "@flatten-js/core";

export interface ITargetWall {
    dig(holeVertices: Flatten.Polygon): void;
}

export class TargetWall implements ITargetWall {

    hCount: number = 10;
    vCount: number = 10;

    private polygons: Array<Flatten.Polygon> = [];
    getPolygons(): Array<Flatten.Polygon> {
        return this.polygons;
    }

    initialize(rect: Rect) {
        let x_differential = rect.width / this.hCount;
        let y_differential = rect.height / this.vCount;
        for (let i = 0; i < this.vCount; i++) {
            for (let j = 0; j < this.hCount; j++) {
                let polygon = new Flatten.Polygon([
                    [rect.x + j * x_differential,rect.y + i * y_differential],
                    [rect.x + (j + 1) * x_differential, rect.y + i * y_differential],
                    [rect.x + (j + 1) * x_differential, rect.y + (i + 1) * y_differential],
                    [rect.x + j * x_differential, rect.y + (i + 1) * y_differential]
                ]);
                this.polygons.push(polygon);
            }
        }
    }

    dig(holeVertices: Flatten.Polygon) {
        this.polygons = PolygonUtility.diff(this.polygons, holeVertices);
    }
}