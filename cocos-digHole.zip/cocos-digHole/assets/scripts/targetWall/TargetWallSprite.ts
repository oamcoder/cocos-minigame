import { Vec3 } from "cc";
import { SpriteFrame } from "cc";
import { Sprite, __private } from "cc";
import { _decorator, Component } from "cc";
const { ccclass } = _decorator;

@ccclass
export class TargetWallSprite extends Sprite {

    _flushAssembler(/*render: __private._cocos_2d_renderer_i_batcher__IBatcher*/) {
        const assembler = Sprite.Assembler.getAssembler(this);

        if (this._assembler !== assembler) {
            this.destroyRenderData();
            this._assembler = assembler;
        }

        if (!this.renderData) {
            if (this._assembler && this._assembler.createData) {
                this._renderData = this._assembler.createData(this);
                this.renderData!.material = this.getRenderMaterial(0);
                this.markForUpdateRenderData();
                if (this.spriteFrame) {
                    this._assembler.updateUVs(this);
                }
                this._updateColor();
            }
        }

        // Only Sliced type need update uv when sprite frame insets changed
        if (this._spriteFrame) {
            // if (this._type === SpriteType.SLICED) {
            //     this._spriteFrame.on(SpriteFrame.EVENT_UV_UPDATED, this._updateUVs, this);
            // } else {
            //     this._spriteFrame.off(SpriteFrame.EVENT_UV_UPDATED, this._updateUVs, this);
            // }
        }
    }
}