import {_decorator, Component, Vec2, Input, EventTouch} from 'cc';
import { IMain } from '../Main';
import { PolygonUtility } from '../PolygonUtility';

const {ccclass, property} = _decorator;

export type TouchParam = {
    point: PolygonUtility.Point,
    connectHole: boolean,
    delta: PolygonUtility.Point
}

@ccclass
export class Touch extends Component {

    protected start(): void {
        this.node.on(Input.EventType.TOUCH_START, this.onTouchStart, this);
        this.node.on(Input.EventType.TOUCH_MOVE, this.onTouchMove, this);
        this.node.on(Input.EventType.TOUCH_END, this.onTouchEnd, this);
    }

    protected onDestroy(): void {
        this.node.off(Input.EventType.TOUCH_START, this.onTouchStart, this);
        this.node.off(Input.EventType.TOUCH_MOVE, this.onTouchMove, this);
        this.node.off(Input.EventType.TOUCH_END, this.onTouchEnd, this);
    }

    private mainControl: IMain;

    initialize(mainControl: IMain) {
        this.mainControl = mainControl;
    }

    private touchId: number = null;

    private isSameTouch(touchId: number) : boolean {
        return this.touchId == touchId;
    }

    private onTouchStart(event: EventTouch) {
        let touchId = event.touch.getID();
        if (this.touchId == null) {
            this.touchId = touchId;
        }
        if (!this.isSameTouch(touchId)) {
            return;
        }  
        this.emitHoleCreate(event.touch.getUILocation());
    }

    private onTouchMove(event: EventTouch) {
        let touchId = event.touch.getID();
        if (!this.isSameTouch(touchId)) {
            return;
        }
        this.emitHoleCreate(event.touch.getUILocation(), event.getUIDelta());
    }

    private onTouchEnd(event: EventTouch) {
        let touchId = event.touch.getID();
        if (this.isSameTouch(touchId)) {
            this.touchId = null;
        }
    }

    private emitHoleCreate(point: Vec2, delta: Vec2 = null) {
        this.mainControl.tryDig({
            point: this.mainControl.convertTouchPoint(point),
            connectHole: delta != null,
            delta: PolygonUtility.vec2ToPoint(delta)
        });
    }
}

