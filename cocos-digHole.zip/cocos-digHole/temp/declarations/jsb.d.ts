/// <reference path="/Applications/Cocos/Creator/3.7.4/CocosCreator.app/Contents/Resources/resources/3d/engine/@types/jsb.d.ts"/>
